package Exercicios;

public class Num4 {

	public static void main(String[] args) {
		
		int a[] = {1, 2, 3, 4, 5};
		int b[] = {6, 7, 8, 9, 10};
		int c[] = new int[10];
		
		for (int i = 0; i < 5; i++) {
			c[i] = a[i];
		}
		for (int i = 0; i < 5; i++) {
			c[i + 5] = b[i];
		}
		for (int i = 0; i < 10; i++) {
			System.out.println(c[i]);
		}
	}
}
