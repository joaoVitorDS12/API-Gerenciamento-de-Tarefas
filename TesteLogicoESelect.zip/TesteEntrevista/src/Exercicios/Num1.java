package Exercicios;

import java.util.Scanner;

public class Num1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite o valor de X: ");
		int x = sc.nextInt();
		
		System.out.println("Digite o valor de Y:");
		int y = sc.nextInt();
		
		int z = (x*y) + 5;
		
		if(z <= 0) {
			System.out.println("A resposta � A: " + z);
		} else if(z <= 100) {
			System.out.println("A resposta � B: " + z);
		}else {
			System.out.println("A resposta � C: " + z);
		}
		
		sc.close();
	}
}
