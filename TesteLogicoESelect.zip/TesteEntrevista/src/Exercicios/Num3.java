package Exercicios;

public class Num3 {
	
	 public static void main(String[] args){
	        int contador=1;
	       
	        System.out.println("......R.E.S.P.O.S.T.A.......");
	        while(contador<=10){
	            System.out.println("("+(contador++)+", 1 2 3 4 5 6 7 8 9 10) ");
	        }
	    }
}
