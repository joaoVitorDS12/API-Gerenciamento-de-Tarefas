package Exercicios;

import java.util.Scanner;
public class Num2 {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int soma = 0;
		int produto = 0;
		
		int m1, m2, h1, h2;
		
		System.out.println("Digite a idade do Homem 1: ");
		h1 = sc.nextInt();
		System.out.println("Digite a idade do Homem 2: ");
		h2 = sc.nextInt();
		System.out.println("Digite a idade da Mulher 1: ");
		m1 = sc.nextInt();
		System.out.println("Digite a idade da Mulher 2: ");
		m2 = sc.nextInt();
		
		if(h1 > h2) {
			if( m1 < m2) {
				soma = h1 + m1;
				produto = h2 * m2;
			}else {
				soma = h1+ m2;
				produto = h2 * m1;
			}
		}else if(m1 < m2) {
			soma = h2 + m1;
			produto = h1 * m2;
		}else {
			soma = h2 + m2;
			produto = h1 * m1;
		}
		
		System.out.println(soma);
		System.out.println(produto);
		
		sc.close();
	}
}
